
public class Arrays {
	public static void main(String args[])
	{
		//int[][] arr = new int[6][3];
		/*arr[4][0]=1;
		arr[4][1]=8;*/
		int arr[][]={{1,2,3},null,{2,4}};  
		
		System.out.println(arr[2].length);
		
	}

}
