
public class PracticeClass {

	public static void main(String[] args) {
		//SingletonClass sc=new SingletonClass();

	}

}
