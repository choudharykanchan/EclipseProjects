
public class PrintAlphabets {
public static void main(String args[])
{
	
	for(char i='a'; i<='z';i++)
	{
		System.out.println(i);
		
	}
	
}
}
